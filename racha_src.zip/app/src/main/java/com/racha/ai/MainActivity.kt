package com.racha.ai
import rikka.shizuku.Shizuku
import android.content.pm.PackageManager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.core.content.ContextCompat
import com.racha.ai.core.proactive.ProactiveScheduler
import com.racha.ai.core.media.IptvManager
import kotlinx.coroutines.launch
import com.racha.ai.ui.navigation.RachaApp
import com.racha.ai.ui.theme.RachaTheme


private const val SHIZUKU_REQUEST_CODE = 1001

class MainActivity : ComponentActivity() {

    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(this, "✅ تم تفعيل الإشعارات", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "⚠️ الإشعارات معطلة. قد لا تعمل الاستباقية أو الفقاعة.", Toast.LENGTH_LONG).show()
        }
    }


    private fun ensureShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                return
            }

            if (
                Shizuku.checkSelfPermission() !=
                PackageManager.PERMISSION_GRANTED
            ) {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
            }
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        ensureShizukuPermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // تهيئة Shizuku وطلب الصلاحية عند توفر Binder
        try {
            Shizuku.addBinderReceivedListenerSticky {
                runOnUiThread {
                    ensureShizukuPermission()
                }
            }

            // مهم: إذا كانت خدمة Shizuku تعمل قبل فتح Racha
            // فلن يكفي مستمع Binder وحده، لذلك نفحصها فوراً.
            if (Shizuku.pingBinder()) {
                ensureShizukuPermission()
            }
        } catch (_: Throwable) {
        }


        // طلب إذن الإشعارات (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        checkOverlayPermission()

        // 🚀 تفعيل مراقبة الإنترنت والعمل الاستباقي لـ JARVIS
        ProactiveScheduler.scheduleNewsWorker(this)
        
        // ✅ تحميل قوائم الأفلام والقنوات العربية تلقائياً
        val iptvManager = IptvManager(this)
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            iptvManager.loadCustomM3uFromUrl("https://iptv-org.github.io/iptv/categories/movies.m3u", "movies.m3u")
            iptvManager.loadCustomM3uFromUrl("https://iptv-org.github.io/iptv/languages/ara.m3u", "arabic.m3u")
        }

        setContent {
            RachaTheme {
                RachaApp()
            }
        }
    }

    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                // متاح للمستقبل
            }
        }
    }
}
